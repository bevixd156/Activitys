package com.devst.app;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class PerfilActivity extends AppCompatActivity {

    private TextView tvNombre, tvCorreo, tvPassword;
    private Button btnAcerca;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_perfil);

        // Conectamos las variables del activity_perfil.xml
        tvNombre = findViewById(R.id.tvNombre);
        tvCorreo = findViewById(R.id.tvCorreo);
        tvPassword = findViewById(R.id.tvPassword);
        btnAcerca = findViewById(R.id.btnAcerca);

        //Recibimos los datos de HomeActivity
        Intent intent = getIntent();
        String name = intent.getStringExtra("name_usuario");
        String email = intent.getStringExtra("email_usuario");
        String pass = intent.getStringExtra("pass_usuario");

        //Mostramos los datos
        tvNombre.setText("Nombre: " + name);
        tvCorreo.setText("Correo: " + email);
        tvPassword.setText("Contraseña: " + pass);

        //Redireccion a nuestra página de GitHub
        btnAcerca.setOnClickListener(View ->{
            Uri url = Uri.parse("https://github.com/bevixd156/Activitys");
            Intent verWeb = new Intent(Intent.ACTION_VIEW, url);
            startActivity(verWeb);
        });

    }
}